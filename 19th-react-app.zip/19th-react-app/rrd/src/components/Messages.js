import React from 'react'
import TopNavigation from './TopNavigation'

function Messages() {
  return (
    <div >
        <TopNavigation/>
      <h3 style={{
        backgroundColor:"burlywood",
        width:300,
        position:'fixed',
        top:100,
        left:'60%'
      }}>🌙 Dinner Diet :</h3>

<select 
style={{
        
        width:300,
        position:'fixed',
        left:"60%",
        top:160,
        backgroundColor:"rgba(158, 187, 217, 1)"
      }}


>
  <option disabled selected> 🌙 Dinner Diet </option>
  <optgroup label="🌙 Dinner Diet">
  <option value="grilled-chicken-salad">
    🥗 Grilled Chicken Salad – Lean chicken, greens, olive oil, seeds
  </option>
  <option value="paneer-quinoa-bowl">
    🍲 Paneer Quinoa Bowl – Quinoa, paneer cubes, veggies, herbs
  </option>
  <option value="salmon-brown-rice">
    🐟 Salmon with Brown Rice – Grilled salmon, brown rice, steamed veggies
  </option>
  <option value="dal-chapati">
    🥘 Dal & Chapati – Whole wheat roti, protein-rich dal, salad
  </option>
  <option value="chicken-soup-meal">
    🍵 Chicken Soup Meal – Clear chicken soup, veggies, multigrain toast
  </option>
  <option value="tofu-stirfry">
    🥦 Tofu Stir-Fry – Tofu with bell peppers, broccoli, sesame seeds
  </option>
  <option value="egg-white-omelette">
    🍳 Egg White Omelette – Protein-rich omelette with spinach & mushrooms
  </option>
  <option value="mediterranean-bowl">
    🥗 Mediterranean Bowl – Hummus, falafel, pita, veggies, olives
  </option>
  <option value="grilled-prawn-rice">
    🦐 Grilled Prawn & Rice – Spiced prawns with steamed rice & salad
  </option>
  <option value="veggie-soup-meal">
    🥣 Veggie Soup Meal – Hot vegetable soup with whole-grain bread
  </option>
</optgroup>

</select>

    </div>
  )
}

export default Messages
