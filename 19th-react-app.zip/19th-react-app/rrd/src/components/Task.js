import React from 'react'
import TopNavigation from './TopNavigation'

function Task() {
  return (
    <div>
        <TopNavigation/>
     <h3  style={{
        backgroundColor:"burlywood",
        width:295,
        position:'fixed',
        top:100,
        
        
        left:'45%',
      }}>Evening Diet:</h3>

<select style={{
  position:'fixed',
        left:'45%',
        top:160,
        width:295,
        backgroundColor:"rgba(158, 187, 217, 1)"

}}>
  <option disabled selected>Break Time</option>
  <optgroup label="☕ Evening Snacks">
    <option value="samosa">
      🥟 Samosa – Crispy fried snack stuffed with spiced potatoes/peas
    </option>
    <option value="veg-sandwich">
      🥪 Veg Sandwich – Brown bread, cucumber, tomato, chutney
    </option>
    <option value="paneer-pakora">
      🧀 Paneer Pakora – Deep-fried paneer fritters with chutney
    </option>
    <option value="chicken-roll">
      🌯 Chicken Roll – Paratha stuffed with chicken, onion & sauces
    </option>
    <option value="egg-puff">
      🥚 Egg Puff – Puff pastry with spiced egg filling
    </option>
    <option value="grilled-fish">
      🐟 Grilled Fish – Lightly spiced fish served with salad
    </option>
  </optgroup>
</select>


    </div>
  )
}

export default Task
