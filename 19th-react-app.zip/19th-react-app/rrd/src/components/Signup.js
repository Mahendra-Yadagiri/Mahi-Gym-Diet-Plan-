import React from 'react'
import { Link } from 'react-router-dom'

function Signup() {
  return (
    <div className='App'>
      <form className='form2'>
        <h1 style={{backgroundColor:"green",color:"burlywood",fontSize:"2.2rem"}}>Add Details</h1>
        <div>
            <label>First Name:</label>
            <input></input>
        </div>
        <div>
            <label>Last Name:</label>
            <input></input>
        </div>
        <div>
            <label>Age:</label>
            <input></input>
        </div>
        <div>
            <label>Email:</label>
            <input></input>
        </div>
        <div>
            <label>Password:</label>
            <input></input>
        </div><div>
            <label>Mobile no:</label>
            <input></input>
        </div>
        <div>
            <label>Profile Pic:</label>
            <input type="file"  className='img' accept='image/*'></input>
        </div>
        <div>
            <button type="button">Signup</button>
        </div>
      </form>
      <br></br>
      <br></br>
      <Link to='/'><b style={{backgroundColor:"rgba(72, 165, 202, 1)"}}>login</b></Link>
    </div>
  )
}

export default Signup
