import React, { useEffect, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom'

function Login() {
  let navigate = useNavigate();
  let emailInputRef=useRef();
  let passwordInputRef=useRef();

  useEffect(()=>{
    if(localStorage.getItem("email") && 
      localStorage.getItem("password")){
    emailInputRef.current.value = localStorage.getItem("email");
    passwordInputRef.current.value=localStorage.getItem("password");
    // onLogin();

    }

    

  },[]);
  let onLogin=()=>{

     if(emailInputRef.current.value==="mahendra45@gmail.com" && 
                passwordInputRef.current.value==="mahi@1234"){
                  localStorage.setItem("email",emailInputRef.current.value);
                  localStorage.setItem("password",passwordInputRef.current.value);

            sessionStorage.setItem("email",emailInputRef.current.value);
                  sessionStorage.setItem("password",passwordInputRef.current.value);

                  navigate("/dashboard");

              }else{
                alert("Invalid Email & Password");

              }

  }
  
  
  return (
   
    <div className='App' >
      <form className="form1"  >
        <h4 style={{color:"yellow",fontSize:"1.5rem"}}>Weekly 6 Days Diet Plan</h4>
        <div>
            <label>Email:</label>
            <input ref={emailInputRef}></input>
        </div>
         <div>
            <label>Password:</label>
            <input ref={passwordInputRef}></input>
        </div>
        
         <div>
            <button type='button' onClick={()=>{
              // if(emailInputRef.current.value==="mahendra45@gmail.com" && 
              //   passwordInputRef.current.value==="mahi@1234"){
              //     localStorage.setItem("email",emailInputRef.current.value);
              //     localStorage.setItem("password",passwordInputRef.current.value);
              //     navigate("/dashboard");

              // }else{
              //   alert("Invalid Email & Password");

              // }
              onLogin();

            }}>Login</button>
        </div>
       <Link to={'/signup'} style={{backgroundColor:"rgba(72, 202, 78, 1)"}}>Signup</Link>
       
      </form>
      <br></br>
      <br></br>
      {/* <Link to={'/signup'}><b style={{backgroundColor:"rgba(72, 202, 100, 1)"}}>Signup</b></Link> */}
    </div>
   
  )
}

export default Login
