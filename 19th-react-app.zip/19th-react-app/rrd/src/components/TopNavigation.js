import React from 'react'
import {NavLink } from 'react-router-dom'

function TopNavigation() {
    let highLightlink=(obj,bgColor,txtColor)=>{
         if(obj.isActive===true){
            return  {backgroundColor:bgColor,color:txtColor}

        }


    }
  return (
    <div>
   {/* <nav>
    <Link to="/dashboard">Dashboard</Link>
    <Link to="/msges">Messages</Link>
    <Link to="/tasks">Tasks</Link>
    <Link to="/leaves">Leaves</Link>
    <Link to="/">Signout</Link>
   </nav> */}
  
   <nav>
    <NavLink style={(obj)=>{
        return highLightlink(obj,"yellow","black");
        
    }} to="/dashboard">
    Breakfast</NavLink>
   
   <NavLink   style={(obj)=>{
        return highLightlink(obj,"black","aqua");
        
    }} to="/leaves">Lunch</NavLink>

    {/* <NavLink  style={(obj)=>{
        return highLightlink(obj,"black","yellow");
        
    }}
     to="/msges">Fish Recipes</NavLink> */}
    <NavLink   style={(obj)=>{
        return highLightlink(obj,"brown","aliceblue");
        
    }} to="/tasks">BreakTime </NavLink>

    <NavLink  style={(obj)=>{
        return highLightlink(obj,"black","yellow");
        
    }}
     to="/msges">Dinner</NavLink>
    
    <NavLink   style={(obj)=>{
        return highLightlink(obj,"orange","black");
        
    }} to="/"><b 
    style={{ 
        backgroundColor:'rgba(139, 161, 104, 1)'
       
        
    }}>Signout</b></NavLink>
   </nav>
   <p style={{color:"rgba(214, 214, 236, 1)",position:"relative",bottom:"-200px"}}>A healthy weekly diet plan includes energizing breakfasts like oats, eggs, smoothies, or idlis to kickstart the day. For lunch, go with balanced meals of rice/roti, dal, veggies, and a protein source such as chicken, fish, or paneer, while evenings are best with light snacks like nuts, seeds, sprouts, or a protein shake. Dinner should stay light, with soups, grilled meats or paneer, stir-fried veggies, or quinoa to support recovery and good sleep.</p>
   </div>
  )
}

export default TopNavigation
