import React from 'react'
import TopNavigation from './TopNavigation'
import { useLocation } from 'react-router-dom'

function Dashboard() {
  let loc= useLocation();
  console.log(loc);
  return (
    
    <div>
      
        <TopNavigation/>
        {/* <h1 style={{
          color:"rgba(225, 221, 210, 1)",
          width:300,
          backgroundColor:"rgb(90,70,50)",
        }}>Coupon no: {loc && loc.state && loc.state.msg ? loc.state.msg:""}</h1> */}
      <h3  
       style={{
        backgroundColor:"burlywood",
        width:300,
        position:"fixed",
        top:100,}}>🍎 Common Everyday Fruits</h3>

<select style={{
  width:300,
  backgroundColor:"rgba(158, 187, 217, 1)",
  position:"fixed",
  top:160
}}>
  <option disabled selected>🍎 Common Everyday Fruits</option>
  <optgroup label="🍎 Common Everyday Fruits">
    <option value="chicken-biryani">
      🍏 Apples
    </option>
    <option value="butter-chicken">
      🍌 Bananas
    </option>
    <option value="chicken-tikka-masala">
      🍊 Oranges
    </option>
    <option value="chicken-65">
      🍇 Grapes
    </option>
    <option value="chicken-manchurian">
      🥭 Mangoes
    </option>
    <option value="chicken-chettinad">
      🍈 Papayas
    </option>
  </optgroup>
</select>

    </div>
    
  )
}

export default Dashboard
