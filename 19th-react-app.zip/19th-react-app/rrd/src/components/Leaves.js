import React from 'react'
import TopNavigation from './TopNavigation'

function Leaves() {
  return (
    <div>
        <TopNavigation/>
        <h3 
        style={{
          backgroundColor:"burlywood",
        width:225,
        position:'fixed',
        top:100,
        left:"30%",
        }}>🍽️ Meals afternoon:</h3>


        <select  
  style={{
    width: 300,
    position: 'fixed',
    left: "30%",
    top: 160,
    backgroundColor: "rgba(158, 187, 217, 1)"
  }}
>
  <option disabled selected>🍽️ Select a Meal</option>

  <optgroup label="Afternoon Meals">
    <option value="chicken-thali">
      🍗 Chicken Thali – Rice/roti, chicken curry, fry, rasam, curd
    </option>
    <option value="mutton-meal">
      🥘 Mutton Meal – Mutton curry, rice, dal, fry, salad, curd
    </option>
    <option value="fish-thali">
      🐟 Fish Thali – Rice, fish curry, fish fry, rasam, curd
    </option>
    <option value="egg-curry-meal">
      🥚 Egg Curry Meal – Rice, egg curry, fry, dal, curd
    </option>
    <option value="chicken-biryani-meal">
      🍛 Chicken Biryani Meal – Biryani with chicken curry, salan & raita
    </option>
    <option value="prawn-meal">
      🦐 Prawn Meal – Rice, prawn curry, fry, rasam, curd
    </option>
  </optgroup>
</select>

{/* <select  
style={{
          
        width:225,
        position:'fixed',
        left:820,
        top:160,
        backgroundColor:"rgba(158, 187, 217, 1)"
        }}>
  <option disabled selected>🍽️ Select a Meal</option>
  <optgroup label="🍽️ Meals">
    <option value="south-indian-meals">
      🥗 South Indian Veg Meals (Thali) – Rice, sambar, rasam, curd, poriyal, papad
    </option>
    <option value="hyderabadi-biryani-meal">
      🍛 Hyderabadi Biryani Meal – Biryani with mirchi ka salan & raita
    </option>
    <option value="north-indian-thali">
      🍲 North Indian Thali – Roti, dal, sabzi, paneer curry, rice, curd, sweet
    </option>
    <option value="andhra-bhojanam">
      🍚 Andhra Bhojanam – Rice with pappu, pulusu, fry, pachadi, rasam, curd
    </option>
    <option value="kerala-sadya">
      🍃 Kerala Sadya – Traditional banana leaf meal with avial, olan, payasam
    </option>
    <option value="punjabi-thali">
      🥘 Punjabi Thali – Rajma, chole, butter naan, paneer curry, lassi
    </option>
  </optgroup>
</select> */}


      
    </div>
  )
}

export default Leaves
