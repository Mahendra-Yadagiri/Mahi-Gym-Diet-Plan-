import React from 'react'

function PageNotFound() {
  return (
    <div>
      <img src="https://codes4education.com/wp-content/uploads/2020/10/404-Error-Page-UI-Design-new-min.png"></img>
    </div>
  )
}

export default PageNotFound
