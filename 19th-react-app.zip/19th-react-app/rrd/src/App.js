import './App.css';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Login from './components/Login';
import Signup from './components/Signup';
import Dashboard from './components/Dashboard';
import Messages from './components/Messages';
import Leaves from './components/Leaves';
import Task from './components/Task';
import TopNavigation from './components/TopNavigation';
import PageNotFound from './components/PageNotFound';

function App() {
  return (
    <BrowserRouter>
    <br></br>
    <br></br>
   <Routes>
    <Route path='/' element={<Login/>}></Route>
    <Route path='/signup' element={<Signup/>}></Route>
    <Route path='/dashboard' element={<Dashboard/>}></Route>
    <Route path='/msges' element={<Messages/>}></Route>
    <Route path='/leaves' element={<Leaves/>}></Route>
    <Route path='/tasks' element={<Task/>}></Route>
    <Route path='/topNavigation' element={<TopNavigation/>}></Route>
    <Route path='*' element={<PageNotFound/>}></Route>
   </Routes>
    </BrowserRouter>
  );
}

export default App;
